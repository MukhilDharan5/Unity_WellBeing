#!/bin/sh
set -eu
PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
UNITY_TOOLS="$PROJECT_DIR/../Unity/Unity_Android/.tools"

# Prefer caller-supplied tools; the sibling Unity checkout is a convenient fallback.
if [ -z "${JAVA_HOME:-}" ] && [ -x "$UNITY_TOOLS/jdk21/bin/java" ]; then
    export JAVA_HOME="$UNITY_TOOLS/jdk21"
fi
if [ -z "${ANDROID_HOME:-}" ] && [ -d "$UNITY_TOOLS/android-sdk" ]; then
    export ANDROID_HOME="$UNITY_TOOLS/android-sdk"
fi
if [ -z "${ANDROID_HOME:-}" ]; then
    echo "Set ANDROID_HOME to an Android SDK with platform 37 and build tools installed." >&2
    exit 1
fi
export GRADLE_USER_HOME="${GRADLE_USER_HOME:-$PROJECT_DIR/.tools/gradle}"
mkdir -p "$PROJECT_DIR/android/.signing" "$PROJECT_DIR/dist"
chmod 700 "$PROJECT_DIR/android/.signing"
printf 'sdk.dir=%s\n' "$ANDROID_HOME" > "$PROJECT_DIR/android/local.properties"
if [ ! -f "$PROJECT_DIR/android/.signing/debug.keystore" ]; then
    "${JAVA_HOME:+$JAVA_HOME/bin/}keytool" -genkeypair -keystore "$PROJECT_DIR/android/.signing/debug.keystore" \
        -storepass android -keypass android -alias androiddebugkey \
        -dname "CN=Unity Health Development,O=Unity,C=IN" -keyalg RSA -keysize 2048 -validity 10000
fi
chmod 600 "$PROJECT_DIR/android/.signing/debug.keystore"
cd "$PROJECT_DIR/android"
if [ -x "$UNITY_TOOLS/gradle-9.6.0/bin/gradle" ]; then
    "$UNITY_TOOLS/gradle-9.6.0/bin/gradle" --no-daemon --console=plain :app:assembleRelease :app:testDebugUnitTest
else
    ./gradlew --no-daemon --console=plain :app:assembleRelease :app:testDebugUnitTest
fi
cp app/build/outputs/apk/release/app-release.apk "$PROJECT_DIR/dist/UnityHealth-0.3.0.apk"
echo "Built $PROJECT_DIR/dist/UnityHealth-0.3.0.apk"
