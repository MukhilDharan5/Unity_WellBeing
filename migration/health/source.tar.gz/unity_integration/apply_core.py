"""Apply the dedicated health bridge to the local Unity core checkout."""
from pathlib import Path
import shutil
ROOT = Path('/home/mukhildharan/Projects_Linux/Backup/Unity')
HERE = Path(__file__).resolve().parent
BACKUP = HERE / 'originals'
def edit(relative, old, new):
    p = ROOT / relative
    s = p.read_text()
    if new in s: return
    assert old in s, (relative, old)
    b = BACKUP / relative
    if not b.exists():
        b.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, b)
    p.write_text(s.replace(old, new, 1))
def copy(source, relative):
    p = ROOT / relative
    assert not p.exists() or p.read_bytes() == (HERE / source).read_bytes(), str(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(HERE / source, p)
android='Unity_Android/app/src/main/'
kt=android+'java/org/unityconnect/companion/'
copy('android/Health.kt', kt+'Health.kt')
p=ROOT / (android+'aidl/org/unityconnect/health/ipc/IUnityHealth.aidl')
p.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(HERE.parent / 'android/app/src/main/aidl/org/unityconnect/health/ipc/IUnityHealth.aidl', p)
edit(android+'AndroidManifest.xml', ' <queries>', ' <uses-permission android:name="org.unityconnect.health.permission.READ_HEALTH" />\n <queries>\n  <package android:name="org.unityconnect.health" />')
edit(android+'AndroidManifest.xml', '  <receiver android:name=".CompanionUpdateReceiver"', '''  <receiver android:name=".HealthSnapshotReceiver" android:exported="true" android:permission="org.unityconnect.health.permission.READ_HEALTH">
   <intent-filter><action android:name="org.unityconnect.health.SNAPSHOT_UPDATED" /></intent-filter>
  </receiver>
  <receiver android:name=".CompanionUpdateReceiver"''')
edit(kt+'Features.kt', '"peripherals", "shell", Continuity.ID)', '"peripherals", "shell", "health", Continuity.ID)')
edit(kt+'Features.kt', ' val files = FileFeature(service)', ' val health = HealthFeature(service)\n val files = FileFeature(service)')
edit(kt+'Features.kt', '  clipboard, files, PhotoFeature', '  clipboard, health, files, PhotoFeature')
edit(kt+'Features.kt', '  shell.settingsChanged(); authentication.settingsChanged();', '  health.settingsChanged(); shell.settingsChanged(); authentication.settingsChanged();')
edit(kt+'CompanionService.kt', ' override fun onDestroy() {', ' override fun onDestroy() {\n  features.health.close()')
edit(kt+'MainActivity.kt', '  val sharing = ui.section(page, "Files and photos")', '  val health = ui.section(page, "Health integration")\n  feature(health, "health", "Health data", "Read existing provider records shared by Unity Health directly with your paired computer.", R.drawable.ic_shield)\n  val sharing = ui.section(page, "Files and photos")')
edit(kt+'MainActivity.kt', '"peripheral_control", "shell", Continuity.ID)', '"peripheral_control", "shell", "health", Continuity.ID)')
edit('Unity_Android/app/build.gradle.kts', 'versionCode = 61', 'versionCode = 62')
edit('Unity_Android/app/build.gradle.kts', 'versionName = "0.1.60"', 'versionName = "0.1.61"')
linux='Unity_Linux/'
copy('linux/health.rs', linux+'unity-plugins/src/health.rs')
edit(linux+'unity-plugins/src/lib.rs', 'pub mod hotspot;', 'pub mod hotspot;\npub mod health;')
edit(linux+'unity-plugins/src/lib.rs', '        Box::new(files::Feature),', '        Box::new(files::Feature),\n        Box::new(health::Feature),')
f=linux+'unityctl/src/gtk_launcher.rs'
edit(f, 'fn checked_script(executable: &Path, phone: bool, messages: bool) -> Result<PathBuf> {', '''fn checked_script(executable: &Path, phone: bool, messages: bool) -> Result<PathBuf> {
    checked_client(executable, if messages { "share/unity-messages/unity_messages.py" }
        else if phone { "share/unity-phone/unity_phone.py" } else { "share/unity/unity.py" })
}

fn checked_client(executable: &Path, relative: &str) -> Result<PathBuf> {''')
edit(f, '''    let script = prefix.join(if messages {
        "share/unity-messages/unity_messages.py"
    } else if phone {
        "share/unity-phone/unity_phone.py"
    } else {
        "share/unity/unity.py"
    });''', '    let script = prefix.join(relative);')
edit(f, '    let script = checked_script(&std::env::current_exe()?, phone, messages)?;', '''    let health = target.is_some_and(|(option, _)| option == "unity-health");
    let executable = std::env::current_exe()?;
    let script = if health { checked_client(&executable, "share/unity-health/unity_health.py")? }
        else { checked_script(&executable, phone, messages)? };''')
edit(f, '        if messages {', '        if health {\n            // The health wrapper supplies its own arguments.\n        } else if messages {')
f=linux+'unityctl/src/main.rs'
edit(f, '    List,', '    /// Open Unity Health with access granted only to its verified child process.\n    LaunchHealth,\n    List,')
edit(f, '        Command::LaunchGtk {', '''        Command::LaunchHealth => {
            gtk_launcher::launch(&bus, &manager, Some(("unity-health", "")), None).await?;
        }
        Command::LaunchGtk {''')

edit(linux+'unity-plugins/src/lib.rs', 'assert_eq!(registry().len(), 36);', 'assert_eq!(registry().len(), 37);')

edit('Unity_Android/app/src/test/java/org/unityconnect/companion/ContinuityTest.kt',
     'assertEquals(34, capabilities.getJSONArray("capabilities").length())',
     'assertTrue(capabilities.getJSONArray("capabilities").toString().contains("\\\"id\\\":\\\"health\\\""))')
print('Applied dedicated health feature, signed IPC, and verified health launcher to Unity')
