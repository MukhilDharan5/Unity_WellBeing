# Unity direct health feature

The integration extends the existing Unity checkouts alongside this project.
`apply_core.py` applies the dedicated Android `health` module, read-only AIDL
binding, laptop plugin, and verified `unityctl launch-health` launcher. Originals
are retained in `originals/` for review. It does not modify pairing credentials,
transport security, file sharing, shell authorization or unrelated features.

The Android Health app stores provider records in its private cache. With Direct
Unity integration enabled, signed Unity companions can bind to `HealthIpcService`.
Both the Android known-signer permission and per-call package/certificate checks
protect the service. The companion verifies the health app's certificate too.
Every request rechecks Health Connect grants. Disabling sharing rejects subsequent
requests, including on an existing binding. No background health-record reads,
sensor permissions, or Health Connect writes are used.

Unity exposes two read-only commands on the paired control channel:

- `health/status {}` returns a header, permission-scoped token and record count.
- `health/page {"token":"…","offset":0,"limit":32}` returns at most 64 records
  and 48 KiB per response, plus the next offset and completion flag.

Tokens change with the private cache or its permitted categories. The desktop
validates consecutive offsets, bounded message/total sizes, provider identity,
and the entire snapshot before one atomic SQLite transaction. A failed or stale
page never commits partial data. Metadata events contain no health measurements.
Results remain owned by the requesting D-Bus connection and use Unity's existing
read/control approval. Pairing, encryption and Bluetooth/LAN routing remain in
Unity. The health application never exports or imports a health transfer file.

The menu launcher uses `unityctl launch-health`. Unity's existing PID/UID-checked
launcher grants only read/control to the exact installed Python child, including
after daemon restarts. Direct `run.sh` launches require normal Unity app-access
approval. No client can approve itself.

Health app signer: `1aebf4a1c2dd1d84961f788a0b5a66eaee8f05eee4229104418febf0b67071b3`.
Production builds must replace development pins with their actual release
certificates on both sides and keep stable signing identities for updates.

## Verification on the paired phone

Verified on the installed Samsung phone and this laptop on 2026-11-23:

- Both installed APK checksums match the built artifacts.
- Google Fit provided 101 records: 24 step totals, 23 distance totals, 28 total
  calorie values and 26 workouts. No active-calorie value was invented.
- Repeated direct refreshes update the same records without duplicates.
- Android denies an unsigned shell caller access to the protected health service.
- Turning Direct Unity integration off immediately blocks Unity health requests;
  turning it back on restores them. Sharing is left enabled.
- The desktop health client reconnects and regains its scoped access automatically
  after a Unity daemon restart.
- No new health file appeared in Unity's received directory during direct sync.
- 26 desktop tests, 6 health Android tests, 199 companion tests, 29 Rust plugin
  tests and the verified-launcher test passed.

The final APKs and their SHA-256 files are under `../dist/`. The complete Unity
source changes are reviewable in `unity-direct-health.patch`.
