//! Bounded direct IPC requests to the paired phone's read-only Unity Health app.
use crate::{text, Plugin, Spec};
use anyhow::{bail, ensure, Result};
use serde_json::Value;

pub struct Feature;
impl Plugin for Feature {
    fn spec(&self) -> Spec {
        Spec { id: "health", title: "Health data", group: "health", sensitive: true,
            blocked: "", actions: &["status", "page"] }
    }
    fn command(&self, action: &str, data: &Value) -> Result<()> {
        let object = data.as_object().ok_or_else(|| anyhow::anyhow!("Health arguments must be an object"))?;
        ensure!(serde_json::to_vec(data)?.len() <= 1024, "Health request is too large");
        match action {
            "status" => ensure!(object.is_empty(), "Status takes no arguments"),
            "page" => {
                ensure!(object.keys().all(|k| ["token", "offset", "limit"].contains(&k.as_str())), "Unknown health argument");
                let token = text(data, "token", 128)?;
                ensure!(!token.is_empty() && token.bytes().all(|c| c.is_ascii_alphanumeric() || b"-_:".contains(&c)), "Invalid health token");
                ensure!(data["offset"].as_u64().is_some_and(|v| v <= 30000), "Invalid health offset");
                if data.get("limit").is_some() { ensure!(data["limit"].as_u64().is_some_and(|v| (1..=64).contains(&v)), "Invalid page limit"); }
            }
            _ => bail!("Unsupported health action"),
        }
        Ok(())
    }
    fn event(&self, data: &Value) -> Result<()> {
        let object = data.as_object().ok_or_else(|| anyhow::anyhow!("Health event must be an object"))?;
        ensure!(object.keys().all(|k| ["state", "snapshot_id", "token", "record_count"].contains(&k.as_str())), "Health events may contain metadata only");
        ensure!(["ready", "unavailable"].contains(&data["state"].as_str().unwrap_or("")), "Invalid health state");
        if data["state"] == "ready" {
            text(data, "snapshot_id", 128)?;
            text(data, "token", 128)?;
            ensure!(data["record_count"].as_u64().is_some_and(|n| n <= 30000), "Invalid health record count");
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;
    #[test]
    fn direct_reads_are_bounded_and_cannot_mutate_health_data() {
        assert!(Feature.command("status", &json!({})).is_ok());
        assert!(Feature.command("page", &json!({"token":"abc:def", "offset":0, "limit":32})).is_ok());
        for (method, value) in [("write", json!({})), ("page", json!({"token":"../file", "offset":0})),
            ("page", json!({"token":"abc", "offset":-1})), ("page", json!({"token":"abc", "offset":0, "limit":65})),
            ("status", json!({"records":[]}))] { assert!(Feature.command(method, &value).is_err()); }
    }
    #[test]
    fn broadcasts_never_carry_health_records() {
        assert!(Feature.event(&json!({"state":"ready","snapshot_id":"one","token":"token","record_count":10})).is_ok());
        assert!(Feature.event(&json!({"state":"ready","records":[1]})).is_err());
    }
}
