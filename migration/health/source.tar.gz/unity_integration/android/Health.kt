package org.unityconnect.companion

import android.content.*
import android.content.pm.PackageManager
import android.os.*
import org.json.JSONObject
import org.unityconnect.health.ipc.IUnityHealth
import java.security.MessageDigest
import java.util.concurrent.Executors

/** Direct, certificate-pinned IPC to Unity Health. No file transfer is involved. */
class HealthFeature(service: CompanionService) : Module(service, "health") {
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var api: IUnityHealth? = null
    @Volatile private var lastError = "Open Unity Health and enable Direct Unity integration"
    private var bound = false
    private var closed = false
    private val permission = "org.unityconnect.health.permission.READ_HEALTH"
    private val packageName = "org.unityconnect.health"
    private val expected = "1aebf4a1c2dd1d84961f788a0b5a66eaee8f05eee4229104418febf0b67071b3"

    private fun verifyServer() {
        val info = service.packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES)
        val signatures = info.signingInfo?.apkContentsSigners.orEmpty()
        check(signatures.size == 1) { "Unexpected Unity Health signer" }
        val actual = MessageDigest.getInstance("SHA-256").digest(signatures.single().toByteArray()).joinToString("") { "%02x".format(it) }
        check(actual == expected) { "Unity Health signing certificate is not trusted" }
        check(granted(permission)) { "Update Unity Health, then update the Unity companion" }
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            runCatching { verifyServer(); api = IUnityHealth.Stub.asInterface(binder); changed() }
                .onFailure { api = null; lastError = it.message ?: "Health IPC unavailable"; service.uiChanged() }
        }
        override fun onServiceDisconnected(name: ComponentName) { api = null; lastError = "Unity Health disconnected"; service.uiChanged() }
        override fun onBindingDied(name: ComponentName) { api = null; main.post { unbind(); if (!closed) main.postDelayed({ connect() }, 1000) } }
        override fun onNullBinding(name: ComponentName) { api = null; lastError = "Unity Health is unavailable"; main.post { unbind() } }
    }

    private fun unbind() { if (bound) runCatching { service.unbindService(connection) }; bound = false }
    private fun connect() { main.post {
        if (closed || bound || !enabled()) return@post
        runCatching {
            verifyServer()
            bound = service.bindService(Intent().setComponent(ComponentName(packageName,
                "org.unityconnect.health.HealthIpcService")), connection, Context.BIND_AUTO_CREATE)
        }.onFailure { lastError = it.message ?: "Install Unity Health first"; service.uiChanged() }
    } }

    private fun request(method: String, args: JSONObject): JSONObject {
        check(Looper.myLooper() != Looper.getMainLooper()) { "Do not read Health IPC on the UI thread" }
        verifyServer()
        val remote = api ?: error("Unity Health is connecting; retry shortly")
        val raw = remote.request(JSONObject().put("version", 1).put("method", method).put("args", args).toString())
        check(raw.toByteArray().size <= 48 * 1024) { "Health response exceeds the message limit" }
        val response = JSONObject(raw)
        check(response.getInt("version") == 1 && response.getBoolean("ok")) { response.optString("error", "Health request failed") }
        return response.getJSONObject("result")
    }

    override fun capability(): JSONObject = status(api != null && lastError.isEmpty(), lastError)

    override fun command(action: String, data: JSONObject): JSONObject {
        require(action in setOf("status", "page")) { "Unsupported health action" }
        require(data.toString().toByteArray().size <= 1024)
        val allowed = if (action == "status") emptySet() else setOf("token", "offset", "limit")
        require(data.keys().asSequence().all { it in allowed })
        return request(action, data)
    }

    fun settingsChanged() {
        if (!enabled()) { main.post { api = null; unbind() }; lastError = "Enable Health data in Features"; return }
        connect()
        changed()
    }

    fun changed() {
        if (closed || !enabled()) return
        connect()
        worker.execute {
            if (api == null || !service.connection.ready) return@execute
            try {
                val status = request("status", JSONObject())
                lastError = ""
                service.event(id, JSONObject().put("state", "ready")
                    .put("snapshot_id", status.getString("snapshot_id"))
                    .put("token", status.getString("token"))
                    .put("record_count", status.getInt("record_count")))
            } catch (error: Exception) {
                lastError = error.message?.take(300) ?: "Health records unavailable"
                runCatching { service.event(id, JSONObject().put("state", "unavailable")) }
            }
            runCatching { service.connection.send(JSONObject().put("type", "capabilities").put("capabilities", service.features.capabilities())) }
            service.uiChanged()
        }
    }

    fun close() { closed = true; worker.shutdownNow(); api = null; main.post { unbind() } }
}

class HealthSnapshotReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == "org.unityconnect.health.SNAPSHOT_UPDATED")
            CompanionService.instance?.features?.health?.changed()
    }
}
