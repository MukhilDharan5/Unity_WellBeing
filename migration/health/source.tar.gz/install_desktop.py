#!/usr/bin/env python3
"""Register this checkout's launcher and app icons for the current user."""

import argparse
import os
from pathlib import Path
import shutil
import subprocess


APP_ID = "io.github.unityhealth.UnityHealth"
ROOT = Path(__file__).resolve().parent


def desktop_quote(value):
    value = str(value).replace("%", "%%")
    for character in ("\\", '"', "`", "$"):
        value = value.replace(character, "\\" + character)
    return '"' + value + '"'


def main():
    parser = argparse.ArgumentParser(description="Install Unity Health's app-menu launcher and icons")
    parser.add_argument("--data-dir", type=Path, help="Use an existing health data directory for this launcher")
    options = parser.parse_args()
    data_home = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share"))
    applications = data_home / "applications"
    icons = data_home / "icons/hicolor/scalable/apps"
    applications.mkdir(parents=True, exist_ok=True)
    icons.mkdir(parents=True, exist_ok=True)
    for suffix in (".svg", "-symbolic.svg"):
        name = APP_ID + suffix
        shutil.copyfile(ROOT / "unity_health/data/icons/scalable/apps" / name, icons / name)
    wrapper = data_home / "unity-health/unity_health.py"
    wrapper.parent.mkdir(parents=True, exist_ok=True)
    arguments = ["--data-dir", str(options.data_dir.resolve())] if options.data_dir else []
    wrapper.write_text("#!/usr/bin/python3\nimport sys\nsys.path.insert(0, " + repr(str(ROOT)) + ")\n"
                       + "sys.argv[1:1] = " + repr(arguments) + "\n"
                       + "from unity_health.application import main\nraise SystemExit(main())\n")
    os.chmod(wrapper, 0o644)
    command = desktop_quote(Path.home() / ".local/bin/unityctl") + " launch-health"
    source = (ROOT / "unity_health/data" / (APP_ID + ".desktop")).read_text()
    source = source.replace("Exec=unity-health", "Exec=" + command)
    destination = applications / (APP_ID + ".desktop")
    destination.write_text(source)
    os.chmod(destination, 0o644)
    if shutil.which("gtk-update-icon-cache"):
        subprocess.run(["gtk-update-icon-cache", "--force", "--ignore-theme-index", str(icons.parents[1])],
                       check=False, capture_output=True)
    if shutil.which("update-desktop-database"):
        subprocess.run(["update-desktop-database", str(applications)], check=False, capture_output=True)
    print("Installed launcher:", destination)
    print("Installed full-color and symbolic icons:", icons)


if __name__ == "__main__":
    main()
