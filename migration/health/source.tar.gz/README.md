# Unity Health

A native libadwaita desktop viewer and native Android companion for your existing
health records. The phone reads **Google Fit, Samsung Health, or Google Health /
Fitbit records shared through Health Connect**. Unity handles the phone-to-laptop
transfer. Unity Health does not record sensor data or write to Health Connect.

The interface keeps neutral native backgrounds, with colored activity rings,
health categories, icons and charts. The Android app uses large health-summary
cards and bottom navigation inspired by Apple Health and Samsung Health.

## Get started

1. Install the updated Unity companion and laptop daemon with the dedicated
   health bridge described in [unity_integration/README.md](unity_integration/README.md).
2. Install `dist/UnityHealth-0.3.0.apk` on your Android phone.
3. In Google Fit, enable **Sync Fit with Health Connect**. Unity Health reads only
   data that the selected provider shares, including calories and distance.
4. In the phone health app's **Sync** tab, select Google Fit, grant read access
   including **Total calories burned** and **Distance**, and refresh.
5. Pair your devices in Unity, enable **Health data** in the companion's Features
   page, and turn on **Direct Unity integration** in the phone health app.
6. Open Unity Health from the laptop app menu. Records sync directly through the
   paired Unity connection while the desktop app is open. Refresh on the phone
   to read newer provider records. **Sync now** requests the latest cached copy.

The app never sends a health export file. No health inbox, file picker or manual
import is used. Background sensor collection and cloud accounts are not needed.
Missing provider data stays empty; calories and distance are never guessed from
steps. Total calories burned includes resting and active energy; active energy
is shown separately and the two are never added together.

Google recommends Health Connect for new mobile integrations, and says the old
Fit APIs will be supported only until the end of 2026. This project uses Health
Connect instead of starting a new integration with the deprecated Fit APIs.
[Google Fit migration guide](https://developer.android.com/health-and-fitness/health-connect/migration/fit)

## What is included

- Desktop: Today, Activity, Sleep, Nutrition, Heart & body, health history, and
  phone sync setup; date navigation, 7/28-day charts, customizable highlight
  cards, editable local goals, and CSV export.
- Android: Summary, Browse and Sync tabs, real provider attribution, category
  history, partial read permissions, local caching, source selection and Unity
  transfer. No sample records are installed or generated.
- Synced categories: steps, workout sessions, active energy, total calories burned, distance, sleep,
  resting heart rate, weight, hydration and nutrition, when the provider shares
  them and read access is allowed.
- Repeat transfers update records by stable identity instead of duplicating
  them. Corrections and deletions are reconciled only within fully read
  categories and the snapshot window. Older snapshots cannot roll back newer
  data; a second phone cannot silently replace the selected phone.
- Legacy personal entries are preserved. The old placeholder records marked
  `sample` are removed automatically when their database is opened. Manual
  recording, mood check-ins, and timed mindfulness recording are no longer app
  features. Health records are edited in the original provider app.

Daily goals are local display settings, not measured health data. Phone activity
rings currently use the labeled defaults (8,000 steps, 45 workout minutes and
400 active kcal); desktop goals remain editable in Preferences. Goal settings
are not synchronized between devices in this version.

## Privacy and data flow

The Android manifest requests **health-read permissions only**. It does not ask
for Internet, body sensors, activity recognition, location, health-write access,
background health reads, or a foreground collection service. Reads are filtered
by the selected provider's package; the app does not include Health Connect's
own phone-step source. There is no analytics or advertising SDK.

Provider records are cached in private Android app storage, with backup disabled.
With Direct Unity integration enabled, only signed, certificate-pinned Unity
companions can read that cache. Each request rechecks current health-read access.
The laptop receives bounded pages through Unity's authenticated paired control
channel and saves them atomically after validating the whole response. No record
values are published in Unity's metadata events. The health app opens no network
listener. Unity owns pairing, encryption and device transport.

Automatic sync can be paused on the laptop or disabled on the phone. Disconnecting
the phone removes this app's synced records and rejects old data; provider records
and legacy personal entries are preserved. Health Connect records refresh when
the phone health app is opened or refreshed, without background health reads.

The desktop database is `$XDG_DATA_HOME/unity-health/health.db`, normally
`~/.local/share/unity-health/health.db`. Override it with `--data-dir` or
`UNITY_HEALTH_DATA_DIR`. Its directory is created with mode `0700` and the database
with `0600`. Local databases and the private phone cache are not encrypted by Unity
Health itself; operating-system account and disk protections apply.

## Desktop dependencies and launcher

Requires Python 3.10+, GTK 4.12+, libadwaita 1.5+, PyGObject and Pycairo.

Fedora:

```sh
sudo dnf install python3-gobject python3-cairo gtk4 libadwaita
```

Ubuntu 24.04 or newer:

```sh
sudo apt install python3-gi python3-gi-cairo gir1.2-gtk-4.0 gir1.2-adw-1
```

Add the application icon and menu launcher:

```sh
/usr/bin/python3 install_desktop.py --data-dir .local-data
```

Keyboard shortcuts: Ctrl+R checks phone sync; Ctrl+, opens Preferences; Ctrl+T
returns to today's date; Ctrl+Q quits.

## Build the Android app

```sh
./build-android.sh
```

The helper reuses the SDK, JDK 21 and Gradle from the sibling Unity Android
checkout when available. Otherwise set `JAVA_HOME` to a JDK and `ANDROID_HOME` to
an SDK containing Android platform 37/build tools, then use the Gradle wrapper.
The project uses AGP 9.4.0, Kotlin/Compose plugin 2.4.21, and the stable Health
Connect client 1.1.0. Minimum supported phone version is Android 9; Android 13 and
lower need the separate Health Connect provider installed. Android 14+ includes
Health Connect in the system. Direct signed Unity integration requires Android 12 or newer.
[Health Connect setup](https://developer.android.com/health-and-fitness/health-connect/get-started)

The optimized APK is written to `dist/UnityHealth-0.3.0.apk`. Release shrinking
keeps the installer small enough for Unity transfers; it uses your persistent
development signing key. Keep
`android/.signing/debug.keystore` if you want future development builds to update
the same installation. Signing material, SDK paths, build caches and outputs are
ignored by version control. The direct bridge requires the Unity companion and daemon updates in
`unity_integration/`. Keep all app signing keys stable for future updates.

## Tests and previews

```sh
/usr/bin/python3 -m unittest discover -s tests -p 'test_store.py' -v
/usr/bin/python3 -m unittest discover -s tests -p 'test_sync.py' -v
GSETTINGS_BACKEND=memory /usr/bin/python3 -m unittest discover -s tests -v
./build-android.sh
```

The desktop suite verifies empty first launch, sample-data migration, snapshot
validation and atomic reconciliation, replay handling, provider attribution,
read-only UI actions, and every screen at 360 pixels wide. The Android build
runs model/serialization and read-only permission tests. Live Health Connect and
direct phone-to-laptop sync still need a paired Android device and its permissions.

The screenshot option renders the actual GTK window without injecting sample
records:

```sh
./run.sh --data-dir /tmp/unity-health-preview --screenshot screenshots/overview.png
./run.sh --data-dir /tmp/unity-health-preview --page sync --screenshot screenshots/sync.png
```

MIT licensed. See [LICENSE](LICENSE).
