"""Unity Health, a local-first native GNOME health journal."""

__version__ = "0.3.0"
